# `starknet_multiple_contracts`

This example showcases how to write multiple Starknet contracts within a single Scarb package.
